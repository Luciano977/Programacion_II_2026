#include <iostream>
#include <cstdio>

#include "archivovendedores.h"


using namespace std;

bool ArchivoVendedores::guardarRegistro(Vendedores reg){

 FILE*p;

 p= fopen("Vendedores.dat", "ab");

 if (p == NULL){

    return false;

 }

  bool escribio= fwrite(&reg, sizeof(Vendedores),1,p);

  fclose(p);

  return escribio;
}

bool ArchivoVendedores::listarRegistros(){

    Vendedores reg;

    FILE *p;

    p= fopen("Vendedores.dat", "rb");

    if (p==NULL){

         return false;
    }

    while (fread(&reg,sizeof(Vendedores),1,p)==1){

        reg.Mostrar();

        cout<<endl;
    }

    fclose(p);

    return true;
}

