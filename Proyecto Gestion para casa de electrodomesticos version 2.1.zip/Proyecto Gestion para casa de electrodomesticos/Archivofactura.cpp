#include <iostream>
#include <cstdio>
#include "Archivofactura.h"

using namespace std;

bool ArchivoFacturas::guardarRegistro(Facturas reg){

  FILE * p;

  p= fopen("Facturas.dat", "ab");


  if (p==NULL){

    return false;

  }

  bool escribio= fwrite(&reg,sizeof(Facturas),1,p);

  fclose(p);

  return escribio;


}

bool ArchivoFacturas::listarRegistros(){

     Facturas reg;

     FILE*p;

     p= fopen("Facturas.dat","rb");

     if (p==NULL){

        return false;


     }

     while (fread(&reg, sizeof(Facturas),1,p)==1){

        reg.Mostrar();

        cout <<endl;
     }

     fclose(p);

     return true;

}
