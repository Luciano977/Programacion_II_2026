#include <iostream>
#include "cobranza.h"

using namespace std;

Cobranza::Cobranza(){

 _letra= 'A';

 _num = 0;

 _importe = 0;

 _estadoCobranza =false;

 _estado = true;

}

void Cobranza::Alta(){

    cout << "Letra de factura: ";
    cin >> _letra;

    cout << "Numero de factura: ";
    cin >> _num;

    cout << "Importe: ";
    cin >> _importe;

    cout << "Estado de cobranza (1 cobrado y 0 con deuda): ";
    cin >> _estadoCobranza;

    _estado= true;

 }

  void Cobranza::Mostrar(){

    if (_estado==false){

        return;
    }

    cout << "Factura: "<< _letra<< " " << _num <<endl;
    cout << "Importe: "<< _importe<<endl;
    cout << "Estado de cobranza: "<< _estadoCobranza<<endl;

  }


  void Cobranza::Baja(){

     _estado=false;

  }
