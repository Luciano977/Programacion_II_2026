#include <iostream>
#include <cstring>
#include "Usuario.h"

using namespace std;

 //constructor

Usuario::Usuario(){

 _CodUsuario=0;

 strcpy(_nomUsuario,"");
 strcpy(_pass,"");
 strcpy(_nivel,"");

 _estado= true;

}


 //setters

 void Usuario::setCodUsuario(int CodUsuario){

    _CodUsuario= CodUsuario;
 }

 void Usuario::setNombreUsuario(const char nomUsuario[]){

    strcpy(_nomUsuario, nomUsuario);
 }

 void Usuario::setPass(const char pass[]){

    strcpy(_pass, pass);

 }

 void Usuario::setNivel(const char nivel[]){

    strcpy(_nivel, nivel);

 }

 void Usuario::setEstado(bool estado){

    _estado= estado;
 }

 //getters

 int Usuario::getCodUsuario(){

     return _CodUsuario;
 }

 const char* Usuario::getnombreUsuario(){

    return _nomUsuario;
 }

 const char* Usuario::getPass(){

    return _pass;

 }

 const char* Usuario::getNivel(){

    return _nivel;

   }

   bool Usuario::getEstado(){

      return _estado;
   }



 //metodos

 void Usuario::Alta(){

    cout<<"Ingrese el codigo de usuario: ";
    cin >>_CodUsuario;

    cout <<"Ingrese nombre de usuario: ";
    cin.getline(_nomUsuario,30);

    cout <<"Ingrese contrasena: ";
    cin.getline(_pass, 50);

    cout <<"Ingrese nivel de usuario: ";
    cin.getline(_nivel, 20);

    _estado = true;

 }

 void Usuario::Modificar(){

    cin.ignore();

    cout <<"Nuevo nombre de usuario: ";
    cin.getline(_nomUsuario, 30);

    cout <<"Nueva contrasena: ";
    cin.getline(_pass, 50);

    cout <<"Nuevo nivel de usuario: ";
    cin.getline(_nivel, 20);


 }

 void Usuario::Baja(){

     _estado = false;
 }

 void Usuario::Mostrar(){

    if (_estado==false){

        return;

    }

    cout <<"Codigo de usuario: "<<_CodUsuario;
    cout <<"Nombre de usuario: "<<_nomUsuario;
    cout <<"Constrasena: "<<_pass;
    cout <<"Nivel de usuario: "<<_nivel;

  }


