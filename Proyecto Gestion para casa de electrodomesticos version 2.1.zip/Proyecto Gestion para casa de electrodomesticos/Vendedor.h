#pragma once

 class Vendedor{

public:

    void menu();

    void consultarClientes();

    void altaCliente();

    void consultarStock();

    void facturarVenta();




 };

