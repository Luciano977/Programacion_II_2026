#pragma once

#include "Vendedores.h"

class ArchivoVendedores{

  public:

      bool guardarRegistro(Vendedores reg);

      bool listarRegistros();




};

