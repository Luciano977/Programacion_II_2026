#include <iostream>

#include "Descrfact.h"

using namespace std;

//constructor

DescrFact::DescrFact(){

 _letra = 'A';

 _numFact = 0;

 _codArticulo = 0;

 _cantidad = 0;

 _estado = true;

}

 //setters

void DescrFact::setLetra(char letra){

 _letra= letra;

}

void DescrFact::setNumFact(int numFact){

     _numFact=numFact;
}

void DescrFact::setCodArt(int codArticulo){

   _codArticulo= codArticulo;

 }

 void DescrFact::setCantidad(int cantidad){

    _cantidad= cantidad;
 }


 void DescrFact::setEstado(bool estado){

    _estado= estado;
 }



 //getters

 char DescrFact::getLetra(){

    return _letra;

 }

 int DescrFact::getCodArticulo(){


    return _codArticulo;
 }

 int DescrFact::getCantidad(){

    return _cantidad;

 }

 int DescrFact::getNumFact(){

     return _numFact;
 }

 bool DescrFact::getEstado(){

    return _estado;
 }

 //metodos


  void DescrFact::Alta(){

    cout <<"Letra de factura: ";
    cin >>_letra;

    cout <<"Numero de factura: ";
    cin>> _numFact;

    cout <<"Codigo de articulo: ";
    cin>>_codArticulo;

    cout <<"Cantidad: ";
    cin >>_cantidad;

    _estado =true ;

  }

  void DescrFact::Modificar(){

     int nuevaCantidad;

    do {

        cout <<"Ingrese nueva cantidad: ";
        cin >>nuevaCantidad;

        if (nuevaCantidad<1){

            cout<<"La cantidad no puede ser menor a 1"<<endl;

        }

    } while (nuevaCantidad<1);

    _cantidad= nuevaCantidad;

  }

  void DescrFact::Baja(){


    _estado= false;

  }

  void DescrFact::Mostrar(){


    if (_estado==false){


        return;
    }

    cout<<"Letra de factura: "<<_letra<<endl;
    cout<<"Numero de factura: "<<_numFact<<endl;
    cout<<"Codigo de articulo: "<<_codArticulo<<endl;
    cout<<"Cantidad: "<<_cantidad<<endl;


   }



