#pragma once
  class Cobranza{

private:


    char _letra;

    int _num;

    float _importe;

    bool _estadoCobranza;

    bool _estado;

public:

    Cobranza();

    void Alta();

    void Mostrar();

    void Baja();



  };



