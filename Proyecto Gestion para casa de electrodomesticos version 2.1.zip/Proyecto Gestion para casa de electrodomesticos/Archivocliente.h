#pragma once


#include "Cliente.h"

class ArchivoClientes{

  public:

      bool guardarRegistro(Cliente reg);

      bool listarRegistros();



};

