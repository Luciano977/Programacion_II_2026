#pragma once
 #include "Usuario.h"

 class ArchivoUsuarios{

public:


    bool guardarRegistros(Usuario reg);

    bool listarRegistros();


 };

