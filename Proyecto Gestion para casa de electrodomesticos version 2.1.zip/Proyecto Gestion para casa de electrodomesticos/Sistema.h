#pragma once


class Sistema{

  public:

      void menu();

      void altaUsuario();

      void otorgarPermisos();

      void Modificar();

      bool estado= true;


};


