#include <iostream>
#include "Fecha.h"

using namespace std;

//constructor

Fecha::Fecha(){

  _dia= 1;

  _mes= 1;

  _anio=2000;

}

//setters

void Fecha::setDia(int dia){

    _dia= dia;

}

void Fecha::setMes(int mes){

  _mes= mes;
}


void Fecha::setAnio(int anio){

 _anio= anio;

}

//getters

int Fecha::getDia(){

  return _dia;
}

int Fecha::getMes(){

  return _mes;
}


int Fecha::getAnio(){

  return _anio;
}


//metodos

void Fecha::Cargar(){

  cout <<"Dia: ";
  cin>>_dia;

  cout << "Mes: ";
  cin >> _mes;

   cout << "Anio: ";
   cin >> _anio;
}

void Fecha::Modificar(){

   Cargar();     //volvemos a llamar a metodo cargar.

 }

 void Fecha::Mostrar(){


     cout << _dia<< "/"<< _mes<< "/"<< _anio;

 }

