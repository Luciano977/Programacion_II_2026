#include <iostream>
#include "Cliente.h"
#include "Archivocliente.h"
#include "Vendedor.h"
#include "Producto.h"
#include "Archivoproducto.h"


using namespace std;

void Vendedor::menu(){

 int opcion;

 while (true){


    system("cls");

    cout <<"----  MENU VENDEDOR ----"<<endl;

    cout <<"1--- CONSULTAR CLIENTES ---"<<endl;
    cout <<"2--- ALTA CLIENTE       ---"<<endl;
    cout <<"3--- CONSULTAR STOCK    ---"<<endl;
    cout <<"4--- FACTURAR VENTA     ---"<<endl;
    cout <<"0--- VOLVER             ---"<<endl;

    cin >> opcion;

    switch (opcion){

  case 1:


    consultarClientes();

    break;

  case 2:

    altaCliente();

    break;

  case 3:

    consultarStock();

    break;

  case 4:

    facturarVenta();

    break;

  case 0:

    return;

  default:

    cout <<"Opcion incorrecta"<<endl;

    }

    system("pause");

 }
}

void Vendedor::consultarClientes(){

 ArchivoClientes archivo;

 archivo.listarRegistros();


}

void Vendedor::altaCliente(){

 Cliente obj;

 ArchivoClientes archivo;

 obj.Alta();

 if (archivo.guardarRegistro(obj)){


    cout <<"Cliente guardado!"<<endl;

 } else {

     cout <<"Error al guardar cliente "<<endl;
  }

}

void Vendedor::consultarStock(){

 ArchivoProducto archivo;

 archivo.listarRegistros();

}

void Vendedor::facturarVenta(){


}
