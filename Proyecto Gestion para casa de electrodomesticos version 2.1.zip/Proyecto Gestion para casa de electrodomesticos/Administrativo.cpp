#include <iostream>
#include "Administrativo.h"

using namespace std;

void Administrativo::menu(){

  int opcion;

  while (true){

    system("cls");

    cout<< "--- MENU ADMINISTRACION --"<<endl;

    cout<<"1---  CONSULTAR STOCK   ---"<<endl;
    cout<<"2---  ACTUALIZAR STOCK  ---"<<endl;
    cout<<"3---  RANKING VENDEDORES --"<<endl;
    cout<<"4---  RECAUDACION       ---"<<endl;
    cout<<"5---  FACTURACION       ---"<<endl;
    cout<<"6---  MOROSIDAD         ---"<<endl;
    cout<<"0---  VOLVER            ---"<<endl;

    cin >> opcion;

    switch (opcion){

 case 1:

    consultarStock();

    break;

 case 2:

    actualizarStock();

    break;

 case 3:

    rankingVendedores();

    break;

 case 4:

     recaudacion();

     break;

 case 5:

    facturacion();

    break;

 case 6:

    morosidad();

    break;

 case 0:

    return;

 default:

    cout <<"Opcion incorrecta"<<endl;



    }



    system("pause");

  }

}

void Administrativo::consultarStock(){

 cout <<"Consultar stock"<<endl;

}

void Administrativo::actualizarStock(){


 cout <<"Actualizar stock"<<endl;

}

void Administrativo::rankingVendedores(){

 cout<<"Ranking de vendedores"<<endl;

}


void Administrativo::recaudacion(){

 cout <<"Recaudacion"<<endl;

}

void Administrativo::facturacion(){

 cout<<"Facturacion"<<endl;

}

void Administrativo::morosidad(){

 cout<<"Morosidad"<<endl;
}
