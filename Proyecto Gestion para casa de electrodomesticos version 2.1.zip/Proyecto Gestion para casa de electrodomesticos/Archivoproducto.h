#pragma once

  #include "Producto.h"

  class ArchivoProducto{

public:

    bool guardarRegistros(Producto reg);

    bool listarRegistros();

  };


