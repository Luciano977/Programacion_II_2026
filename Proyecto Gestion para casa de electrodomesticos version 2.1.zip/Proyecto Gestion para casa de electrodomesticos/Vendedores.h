#pragma once
#include <cstring>

class Vendedores{

 private:

     int _codVendedor;

     char _nombre[50];
     char _apellido[50];

     int _dni;

     char _telefono[30];
     char _email[100];

     bool _estado;

 public:

    Vendedores();

    void Alta();

    void Mostrar();

    void Baja();

};
