#include <iostream>
#include <cstring>
#include "Producto.h"

using namespace std;

//constructor

Producto::Producto(){


 _codArticulo=0;

 strcpy(_descripcion,"");

 _precioUnit= 0;

 _stock =0;

 _estado = true;


}

//setters

 void Producto::setcodArticulo(int codArticulo){

    if (codArticulo>0){

        _codArticulo= codArticulo;

    }
 }

 void Producto::setDescripcion(const char descripcion[]){

    strcpy(_descripcion, descripcion);

 }

 void Producto::setPreciosUnit(float precioUnit){

    _precioUnit= precioUnit;

 }

 void Producto::setEStado(bool estado){

    _estado= estado;
 }

 void Producto::setStock(int stock){

      _stock= stock;

 }

 //getters


 int Producto::getCodArticulo(){

    return _codArticulo;

 }

 const char* Producto::getDescripcion(){

   return _descripcion;

 }

 float Producto::getPrecioUnit(){

    return _precioUnit;
 }

 int Producto::getStock(){

    return _stock;
 }

 bool Producto::getEstado(){

    return _estado;
  }


  //metodos

  void Producto::Alta(){

    cout <<"Codigo de articulo: ";

    cin>> _codArticulo;
    cin.ignore();

    cout <<"Descripcion del producto: ";
    cin.getline(_descripcion, 100);


    cout <<"Precio unitario:$ ";
    cin >> _precioUnit;

    cout <<"Stock: ";
    cin >>_stock;

    _estado = true;

  }

  void Producto::Baja(){

    _estado = false;

  }

  void Producto::Modificar(){

    cin.ignore();

    cout <<"Nueva descripcion: ";
    cin.getline(_descripcion,100);

    cout <<"Nuevo precio:$ ";
    cin >>_precioUnit;

    cout <<"Nuevo stock: ";
    cin >>_stock;
  }

  void Producto::Mostrar(){

    if (_estado==false){

        return;
    }

    cout <<"Codigo de producto: "<<_codArticulo<<endl;
    cout <<"Descripcion: "<<_descripcion<<endl;
    cout <<"Precio:$"<<_precioUnit<<endl;
    cout <<"Stock:"<<_stock<<endl;
  }

