#include <iostream>
#include "Administrativo.h"
#include "Sistema.h"
#include "vendedor.h"




using namespace std;


int main(){

    Sistema adm;

    Administrativo Adminis;

    Vendedor vendedor;

    int opcion;

        while(true){


            system("cls");

            cout <<"=======SISTEMA DE GESTION DE ELECTRODOMESTICOS========"<<endl;
            cout <<"1--             MENU SISTEMA    -- "<<endl;
            cout <<"2--             MENU ADMINISTRACION   -- "<<endl;
            cout <<"3--             MENU VENDEDOR         -- "<<endl;
            cout <<"0--             SALIR                 -- "<<endl;
            cout <<"Seleccione Opcion: ";

            cin>> opcion;

            switch(opcion){


          case 1:

              adm.menu();

              break;

          case 2:

              Adminis.menu();

              break;

          case 3:

              vendedor.menu();

              break;

          case 0:

               return 0;

          default:

              cout <<"Opcion incorrecta" <<endl;


            }

            system("pause");

        }

    return 0;
}
