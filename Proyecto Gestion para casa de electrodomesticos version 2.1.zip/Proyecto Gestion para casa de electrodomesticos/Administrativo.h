#pragma once

class Administrativo{

public:

    void menu();

    void consultarStock();

    void actualizarStock();

    void rankingVendedores();

    void recaudacion();

    void facturacion();

    void morosidad();


};
