#pragma once

  class DescrFact{

private:

    char _letra;

    int _numFact;

    int _codArticulo;

    int _cantidad;

    bool _estado;

public:

    DescrFact();

    //setters

    void setLetra(char letra);

    void setNumFact(int numFact);

    void setCodArt(int codArticulo);

    void setCantidad(int cantidad);

    void setEstado(bool estado);

    //getters

    char getLetra();

    int getNumFact();

    int getCodArticulo();

    int getCantidad();

    bool getEstado();



    //metodss



    void Alta();

    void Modificar();

    void Mostrar();

    void Baja();



  };


