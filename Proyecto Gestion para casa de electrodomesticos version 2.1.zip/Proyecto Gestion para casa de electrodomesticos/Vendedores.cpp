#include <iostream>
#include <cstring>

#include "Vendedores.h"

using namespace std;

Vendedores::Vendedores(){

   _codVendedor=0;

   strcpy(_nombre, "");
   strcpy(_apellido,"");

   _dni = 0;

   strcpy(_telefono, "");
   strcpy(_email, "");

   _estado = true;

}

  void Vendedores::Alta(){

    cout <<"Codigo vendedor: ";
    cin >> _codVendedor;

    cin.ignore();

    cout <<"Nombre: ";
    cin.getline(_nombre, 50);

    cout <<"Apellido: ";
    cin.getline (_apellido, 50);

    cout <<"Dni: ";
    cin>> _dni;

    cin.ignore();

    cout <<"Telefono: ";
    cin.getline(_telefono,30);

    cout <<"Email: ";
    cin.getline(_email, 100);


  }

  void Vendedores::Mostrar(){

    if (_estado==false){

        return;

    }

    cout << "Codigo vendedor: " << _codVendedor << endl;
    cout << "Nombre: " << _nombre << endl;
    cout << "Apellido: " << _apellido << endl;
    cout << "Dni: " << _dni << endl;
    cout << "Telefono: " << _telefono << endl;
    cout << "Email: " << _email << endl;

  }

   void Vendedores::Baja(){

    _estado= false;

   }
