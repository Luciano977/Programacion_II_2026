#pragma once

class Fecha{

   private:

       int _dia;

       int _mes;

       int _anio;

   public:


    Fecha();

    //setters

    void setDia(int dia);

    void setMes(int mes);

    void setAnio(int anio);

    //getters

    int getDia();

    int getMes();

    int getAnio();

    //metodos

    void Cargar();

    void Mostrar();

    void Modificar();

};

