#pragma once

  #include <cstring>

  class Producto{


private:


    int _codArticulo;

    char _descripcion[100];

    float _precioUnit;

    int _stock;

    bool _estado;

public:

    //constructor


    Producto();

    //setters

    void setcodArticulo(int codArticulo);

    void setDescripcion(const char descripcion[]);

    void setPreciosUnit(float precioUnit);

    void setStock(int stock);

    void setEStado(bool estado);

    //getters

    int getCodArticulo();

    const char* getDescripcion();

    float getPrecioUnit();

    int getStock();

    bool getEstado();

    //metodos

    void Alta();

    void Baja();

    void Modificar();

    void Mostrar();

  };


