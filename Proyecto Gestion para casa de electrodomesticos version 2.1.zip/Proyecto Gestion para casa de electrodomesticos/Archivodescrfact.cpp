#include <iostream>
#include <cstdio>
#include "archivodescrfact.h"

using namespace std;

bool ArchivoDescrFact::guardarRegistro(DescrFact reg){


   FILE * p;

   p= fopen("DescrFact.dat","ab");

   if (p=NULL){

    return false;


   }
   bool escribio= fwrite(&reg,sizeof(DescrFact),1,p);

   fclose(p);

   return escribio;

 }

 bool ArchivoDescrFact::listarRegistros(){

    DescrFact reg;

    FILE*p;

    p= fopen("DescrFact.dat", "rb");

    if (p=NULL){

        return false;

    }

    while (fread(&reg, sizeof(DescrFact),1,p)==1){


        reg.Mostrar();

        cout <<endl;

    }

    fclose(p);

    return true;
 }
