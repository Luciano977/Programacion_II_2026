#pragma once

#include "cobranza.h"

class ArchivoCobranzas{

   public:

       bool guardarRegistro(Cobranza reg);

       bool listarRegistro();



};

