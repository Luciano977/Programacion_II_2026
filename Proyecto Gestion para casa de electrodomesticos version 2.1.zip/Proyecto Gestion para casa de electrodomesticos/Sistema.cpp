#include <iostream>
#include "Sistema.h"

using namespace std;

void Sistema::menu(){


        int opcion;

        while (true){


            system("cls");

            cout <<"=====   MENU SISTEMA      ====="<<endl;
            cout <<"1--     ALTA USUARIO      --"<<endl;
            cout <<"2--     OTORGAR PERMISOS  --"<<endl;
            cout <<"0--     VOLVER            --"<<endl;

            cin >> opcion;

            switch(opcion){


        case 1:

            altaUsuario();

            break;

        case 2:

            otorgarPermisos();

            break;

        case 0:

            return;

        default:


            cout <<"Opcion incorrecta"<<endl;


            }

            system("pause");

        }

}

      void Sistema::altaUsuario(){

        cout <<"alta usuario "<<endl;

      }

      void Sistema::otorgarPermisos(){

        cout <<"Otorgar permisos "<<endl;

      }
