#include <iostream>
#include <cstdlib>

#include "Archivocliente.h"

using namespace std;


bool ArchivoClientes::guardarRegistro(Cliente reg){

 FILE *p;

 p= fopen("Clientes.dat","ab");


 if (p==NULL){


     return false;
 }

 bool escribio= fwrite(&reg,sizeof(Cliente),1,p);

 fclose(p);

 return escribio;

}



bool ArchivoClientes::listarRegistros(){

  Cliente reg;

  FILE *p;

  p = fopen("Clientes.dat", "rb");

  if (p==NULL){

    return false;
  }

 while (fread(&reg, sizeof(Cliente),1,p)==1){

    reg.Mostrar();

    cout <<endl;


 }

 fclose(p);

 return true;

}
