#include <iostream>
#include <cstdio>
#include "Archivocobranza.h"


using namespace std;

bool ArchivoCobranzas::guardarRegistro(Cobranza reg){


FILE*p;

p= fopen("Cobranzas.dat","ab");

if (p==NULL){

    return false;
}

bool escribio = fwrite(&reg,sizeof(Cobranza),1,p);

fclose(p);

return escribio;

}

bool ArchivoCobranzas::listarRegistro(){

 Cobranza reg;

 FILE*p;

 p = fopen("Cobranzas.dat","rb");

 if(p==NULL){

    return false;

 }

 while (fread(&reg,sizeof(Cobranza),1,p)==1){


    reg.Mostrar();

    cout <<endl;

 }

 fclose(p);

 return true;


}
