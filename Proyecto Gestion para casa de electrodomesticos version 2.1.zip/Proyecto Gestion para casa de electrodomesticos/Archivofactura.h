#pragma once
  #include "Factura.h"


  class ArchivoFacturas{

public:

    bool guardarRegistro(Facturas reg);

    bool listarRegistros();


  };
