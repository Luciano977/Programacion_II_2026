#pragma once
#include "descrfact.h"

class ArchivoDescrFact{

 public:

     bool guardarRegistro(DescrFact reg);

     bool listarRegistros();




  };

