#include <iostream>
#include <cstdio>

#include "Archivoproducto.h"

using namespace std;

bool ArchivoProducto::guardarRegistros(Producto reg){

  FILE*p;

  p= fopen("Productos.dat","ab");

  if(p==NULL){

    return false;

  }

  bool escribio= fwrite(&reg, sizeof(Producto),1,p);

  fclose(p);

  return escribio;

}

 bool ArchivoProducto::listarRegistros(){

    Producto reg;

    FILE *p;

    p = fopen("Productos.dat","rb");

    if (p==NULL){

        return false;

    }

    while(fread(&reg,sizeof(Producto),1,p)==1){

        reg.Mostrar();

        cout <<endl;


    }

    fclose(p);

    return true;
 }
