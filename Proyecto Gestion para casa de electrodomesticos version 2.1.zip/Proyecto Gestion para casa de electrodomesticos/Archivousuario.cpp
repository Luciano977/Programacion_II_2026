#include <iostream>
#include <cstdio>
#include "Archivousuario.h"

using namespace std;



bool ArchivoUsuarios::guardarRegistros(Usuario reg){

    FILE*p;



    p = fopen("Usuarios.dat","ab");

    if(p == NULL){
        return false;
    }

    bool escribio = fwrite(&reg,sizeof(Usuario),1,p);

    fclose(p);

    return escribio;
}


bool ArchivoUsuarios::listarRegistros(){

    Usuario reg;

    FILE *p;

    p = fopen("Usuarios.dat","rb");

    if(p == NULL){

        return false;
    }

    while(fread(&reg,sizeof(Usuario),1,p) == 1){

        reg.Mostrar();
        cout << endl;
    }

    fclose(p);
    return true;
}

