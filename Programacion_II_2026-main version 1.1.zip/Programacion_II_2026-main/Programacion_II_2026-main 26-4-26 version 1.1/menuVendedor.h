#ifndef MENU_VENDEDOR_H
#define MENU_VENDEDOR_H

int menuVendedor();

#endif
