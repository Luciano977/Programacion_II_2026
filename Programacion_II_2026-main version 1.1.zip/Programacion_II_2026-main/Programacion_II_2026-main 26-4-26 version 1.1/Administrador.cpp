#include<iostream>
#include<string>
#include "Administrador.h"
using namespace std;

void  Administrador::menuAdministrador(){
    int opc;
    while(true){
        system("cls");
        cout << "******** MENU ADMINISTRADOR********" << endl;
        cout << "1. Dar de alta un nuevo usuario " << endl;
        cout << "2. Otorgar permisos a usuarios" << endl;
        cout << "0. Volver al menu anterior" << endl;
        cout << "***********************************" << endl<<endl;
        cout << "Seleccionar opcion  " << endl;
        cin>>opc;

        system("cls");

        switch(opc){
            case 1: void darAltaUsuario();
                    break;
            case 2: void otorgarPermiso();
                    break;
            case 0: return;
                    break;
            default: cout<<"Opcion incorrecta "<<endl;

        }
        system("pause");


    }

}

void Administrador::darAltaUsuario(){
    cout<<"Dar de alta un usuario."<<endl;
}

void Administrador::otorgarPermiso(){
    cout<<"Otorgar permiso al usuario"<<endl;
}
