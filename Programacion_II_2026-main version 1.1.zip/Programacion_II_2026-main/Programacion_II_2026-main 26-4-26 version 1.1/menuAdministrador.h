#ifndef MENU_ADMINISTRADOR_H
#define MENU_ADMINISTRADOR_H

int menuAdministrador();

#endif




