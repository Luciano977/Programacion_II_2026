#ifndef VENDEDOR_H_INCLUDED
#define VENDEDOR_H_INCLUDED

class Vendedor{

 public:

    void menu();
    void consultarClientes();
    void altaClientes();
    void consultarStock();
    void facturarVenta();

};


#endif
