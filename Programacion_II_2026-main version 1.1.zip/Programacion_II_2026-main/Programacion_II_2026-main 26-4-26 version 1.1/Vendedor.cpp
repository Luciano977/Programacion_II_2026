#include <iostream>
#include "vendedor.h"

using namespace std;


void Vendedor::menu(){



int opc;

while (true){

     system("cls");

        cout << "*****Menu vendedor *****" << endl;
        cout << "1. Consultar clientes" << endl;
        cout << "2. Dar de alta clientes" << endl;
        cout << "3. Consultar stock" << endl;
        cout << "4. Facturar venta" << endl;
        cout << "0. Volver al menu anterior" << endl;
        cout << "************************" << endl;
        cin>>opc;

        system("cls");

        switch(opc){

         case 1: consultarClientes(); break;
         case 2: altaClientes(); break;
         case 3: consultarStock(); break;
         case 4: facturarVenta(); break;
         case 0: return;

         default: cout << "Opcion incorrecta" << endl;


        }

        system("pause");

  }

}

     void Vendedor::consultarClientes(){

      cout<<"Listado de clientes "<<endl;

     }

     void Vendedor::altaClientes(){

      cout<<"Alta de cliente "<<endl;

     }

     void Vendedor::consultarStock(){

     cout<<"Cconsulta de stock "<<endl;
     }

     void Vendedor::facturarVenta(){

     cout<<"Facturar venta "<<endl;
     }
