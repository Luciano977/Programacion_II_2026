#ifndef MENU_ADMINISTRACION_H
#define MENU_ADMINISTRACION_H

int menuAdministracion();

#endif
