#include<iostream>
#include "menuAdministracion.h"

using namespace std;

int menuAdministracion(){

int opc;

    while(true){

        system("cls");

        cout <<"********Elegiste menu administracion**********"<<endl;
        cout<<"1. Consultar el stock"<<endl;
        cout<<"2. Actualizar el stock"<<endl;
        cout<<"3. Ranking de vendedores"<<endl;
        cout<<"4. Consulta de recaudacion"<<endl;
        cout<<"5. Consulta de facturacion"<<endl;
        cout<<"6. Reporte de morosidad"<<endl;
        cout<<"0. Retornar al menu anterior"<<endl;
        cout<<"**********************************************"<<endl;
        cin>>opc;

        system("cls");

      switch(opc){

      case 1: cout<<"Elegiste la opcion 1"<< endl; break;
      case 2: cout<<"Elegiste la opcion 2"<< endl; break;
      case 3: cout<<"Elegiste la opcion 3"<< endl; break;
      case 4: cout<<"Elegiste la opcion 4"<< endl; break;
      case 5: cout<<"Elegiste la opcion 5"<< endl; break;
      case 6: cout<<"Elegiste la opcion 6"<< endl; break;
      case 0: return 0;
      default: cout<<"Seleccion incorrecta"<<endl;
      }
      system("pause");

    }

}
