#include <iostream>
#include "menuAdministrador.h"

using namespace std;

int menuAdministrador(){


int opc;

while (true){


    system("cls");

    cout<<"*******Elegiste el menu administrador********"<<endl;
    cout<<"    1. Dar de alta nuevo usuario"<<endl;
    cout<<"    2. Otorgar permisos a usuarios"<<endl;
    cout<<"    0. Retornar al menu anterior"<<endl;
    cout<<"*********************************************"<<endl;
    cout<<"Seleccionar opcion "<<endl;
    cin>>opc;
    system("cls");

    switch(opc){

    case 1: cout<<"Elegiste la opcion 1"<<endl;
    break;

    case 2: cout<<"Elegiste la opcion 2"<<endl;
    break;

    case 0: return 0;
    default: cout<< "La seleccion es incorrecta!"<<endl;


    }
    system("pause");
}

}
