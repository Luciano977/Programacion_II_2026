#ifndef ADMINISTRACION_H
#define ADMINISTRACION_H

class Administracion{
private:
public:
    void menu();
    void consultarStock();
    void actualizarStock();
    void rankingVendedores();
    void recaudacion();
    void facturacion();
    void morosidad();

};

#endif
