#include <iostream>
#include "menuVendedor.h"
using namespace std;


int menuVendedor(){


       int opc;

       while(true){

        system("cls");

        cout<<"********Elegiste el menu vendedor*********"<<endl;
        cout<<"1. Consulta de clientes"<<endl;
        cout<<"2. Dar de alta un cliente"<<endl;
        cout<<"3. Consultar el stock"<<endl;
        cout<<"4. Facturar una venta"<<endl;
        cout<<"0. Regresar al menu anterior"<<endl;
        cout<<"Seleccionar opcion"<<endl;
        cin>>opc;

        system("cls");

        switch(opc){

            case 1: cout<<"Elegiste la opcion 1"<< endl; break;
            case 2: cout<<"Elegiste la opcion 2"<< endl; break;
            case 3: cout<<"Elegiste la opcion 3"<< endl; break;
            case 4: cout<<"Elegiste la opcion 4"<< endl; break;
            case 0: return 0;
            default: cout<<"Opcion incorrecta"<<endl;

        }

        system("pause");
       }


}
