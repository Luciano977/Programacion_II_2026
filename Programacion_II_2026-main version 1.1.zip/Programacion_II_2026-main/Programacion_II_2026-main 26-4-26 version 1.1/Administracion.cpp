#include<iostream>
#include "Administracion.h"
using namespace std;




void Administracion::menu() {
    int opc;
    while(true){
        system("cls");
        cout << "** MENU ADMINISTRACION **" << endl;
        cout << "1. CONSULTAR EL STOCK" << endl;
        cout << "2. ACTUALIZAR EL STOCK" << endl;
        cout << "3. RANKING DE VENDEDORES" << endl;
        cout << "4. RECAUDACION" << endl;
        cout << "5. FACTURACION" << endl;
        cout << "6. MOROSIDAD" << endl;
        cout << "0. VOLVER" << endl;
        cout << "**" << endl;
        cin >> opc;

        switch(opc){
            case 1: consultarStock();
            break;
            case 2: actualizarStock();
            break;
            case 3: rankingVendedores();
            break;
            case 4: recaudacion();
            break;
            case 5: facturacion();
            break;
            case 6: morosidad();
            break;
            case 0: return;
            default: cout<<"Opcion incorrecta"<<endl;
        }

        system("pause");
    }
}

void Administracion::consultarStock() {
    cout << "Consultar stock..." << endl;
}

void Administracion::actualizarStock() {
    cout << "Actualizar actualizar Stock..." << endl;
}

void Administracion::rankingVendedores() {
    cout << "Consultar ranking Vendedores..." << endl;
}

void Administracion::recaudacion() {
    cout << "Consultar recaudacion..." << endl;
}

void Administracion::facturacion() {
    cout << "Consultar facturacion..." << endl;
}

void Administracion::morosidad() {
    cout << "Consultar morosidad..." << endl;
}
