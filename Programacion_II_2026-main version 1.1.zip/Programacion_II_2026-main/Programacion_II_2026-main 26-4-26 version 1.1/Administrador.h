#ifndef ADMINISTRADOR_H_INCLUDED
#define ADMINISTRADOR_H_INCLUDED

class Administrador{
private:
public:
    void menuAdministrador();
    void darAltaUsuario();
    void otorgarPermiso();

};

#endif
